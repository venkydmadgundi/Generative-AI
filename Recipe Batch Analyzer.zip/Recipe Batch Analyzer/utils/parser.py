import json


class ResponseParser:
    """Handles parsing of API responses and recipe data."""

    def parse_api_response(self, response_text):
        # Clean the response text
        cleaned = self.clean_response_text(response_text)

        try:
            # Parse the cleaned text as JSON
            parsed = json.loads(cleaned)

            # Check if parsed result has "analysis" key with list value
            if isinstance(parsed, dict) and isinstance(parsed.get("analysis"), list):
                return parsed["analysis"]

            return []

        except json.JSONDecodeError:
            # Handle JSONDecodeError by returning empty list
            return []
        except Exception:
            return []

    def clean_response_text(self, text):
        if text is None:
            return ""

        # Strip whitespace from text
        cleaned = text.strip()

        # Remove "```json" or "```" from the beginning if present
        if cleaned.startswith("```json"):
            cleaned = cleaned[len("```json"):]
        elif cleaned.startswith("```"):
            cleaned = cleaned[len("```"):]

        # Remove "```" from the end if present
        if cleaned.endswith("```"):
            cleaned = cleaned[:-len("```")]

        # Return cleaned and stripped text
        return cleaned.strip()