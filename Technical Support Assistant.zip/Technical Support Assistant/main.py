import os
from dotenv import load_dotenv
from google import genai
from utils.config import SYSTEM_PROMPT

# Load environment variables
load_dotenv()


class TechSupportChat:

    def __init__(self, api_key=None, max_history=15):
        # Initialize API key from parameter or env var GEMINI_API_KEY
        self.api_key = api_key or os.getenv("GEMINI_API_KEY")

        # Raise ValueError if no key found
        if not self.api_key:
            raise ValueError("GEMINI_API_KEY not found in environment variables.")

        # Initialize Gemini client
        self.client = genai.Client(api_key=self.api_key)

        # Set the model
        self.model = "gemini-2.5-flash"

        # Initialize conversation history storage as a list
        self.conversation_history = []

        # Set max_history limit for conversation history
        self.max_history = max_history

        # Initialize troubleshooting_state
        self.troubleshooting_state = {
            "user_os": None,
            "user_device": None,
            "issue_type": None,
            "attempted_solutions": [],
            "user_tech_level": "unknown",
            "system_info": {},
            "current_step": None,
            "escalation_needed": False,
        }

    def add_to_history(self, role, content, metadata=None):
        """Add message to conversation history with optional metadata."""
        self.conversation_history.append({
            "role": role,
            "content": content,
            "metadata": metadata if metadata is not None else {},
        })

        # Trim if exceeding max_history, preserving all system messages
        if len(self.conversation_history) > self.max_history:
            system_messages = [
                m for m in self.conversation_history if m["role"] == "system"
            ]
            non_system_messages = [
                m for m in self.conversation_history if m["role"] != "system"
            ]

            remaining_slots = max(self.max_history - len(system_messages), 0)
            recent_non_system = non_system_messages[-remaining_slots:] \
                if remaining_slots > 0 else []

            self.conversation_history = system_messages + recent_non_system

    def update_troubleshooting_state(self, key, value):
        """Update a field in the troubleshooting state."""
        if key not in self.troubleshooting_state:
            return

        if key == "attempted_solutions":
            if isinstance(value, str) and value not in self.troubleshooting_state[key]:
                self.troubleshooting_state[key].append(value)
        else:
            self.troubleshooting_state[key] = value

    def get_conversation_context(self):
        """Build the full conversation context string."""
        parts = [SYSTEM_PROMPT]

        state = self.troubleshooting_state
        info_parts = []

        if state.get("user_os"):
            info_parts.append(f"User OS: {state['user_os']}")
        if state.get("user_device"):
            info_parts.append(f"Device: {state['user_device']}")
        if state.get("issue_type"):
            info_parts.append(f"Issue Type: {state['issue_type']}")
        if state.get("attempted_solutions"):
            info_parts.append(
                f"Attempted Solutions: {', '.join(state['attempted_solutions'])}"
            )
        if state.get("user_tech_level") and state["user_tech_level"] != "unknown":
            info_parts.append(f"User Tech Level: {state['user_tech_level']}")

        if info_parts:
            parts.append(
                "TROUBLESHOOTING CONTEXT: " + "; ".join(info_parts)
            )

        # Format conversation history
        history_lines = []
        for msg in self.conversation_history:
            role = msg.get("role")
            content = msg.get("content", "")
            if role == "user":
                history_lines.append(f"User: {content}")
            elif role == "assistant":
                history_lines.append(f"Support: {content}")

        if history_lines:
            parts.append("\n".join(history_lines))

        return "\n\n".join(parts)

    def analyze_user_input(self, user_input):
        """Detect OS, device, issue type, and attempted solutions."""
        if not user_input:
            return

        text = user_input.lower()

        # Detect OS
        if "windows" in text:
            self.update_troubleshooting_state("user_os", "Windows")
        elif "macos" in text or "mac" in text:
            self.update_troubleshooting_state("user_os", "macOS")
        elif "linux" in text:
            self.update_troubleshooting_state("user_os", "Linux")
        elif "ios" in text:
            self.update_troubleshooting_state("user_os", "iOS")
        elif "android" in text:
            self.update_troubleshooting_state("user_os", "Android")

        # Detect device
        if "laptop" in text:
            self.update_troubleshooting_state("user_device", "Laptop")
        elif "desktop" in text:
            self.update_troubleshooting_state("user_device", "Desktop")
        elif "phone" in text:
            self.update_troubleshooting_state("user_device", "Phone")
        elif "tablet" in text:
            self.update_troubleshooting_state("user_device", "Tablet")
        elif "printer" in text:
            self.update_troubleshooting_state("user_device", "Printer")
        elif "router" in text:
            self.update_troubleshooting_state("user_device", "Router")

        # Detect issue type
        if any(k in text for k in ("crash", "crashes", "crashing", "freeze", "freezing")):
            self.update_troubleshooting_state("issue_type", "Software Crash")
        elif any(k in text for k in ("wifi", "internet", "connection", "network", "bluetooth")):
            self.update_troubleshooting_state("issue_type", "Connectivity")
        elif any(k in text for k in ("login", "password", "account", "sign in", "2fa", "two-factor")):
            self.update_troubleshooting_state("issue_type", "Authentication")
        elif any(k in text for k in ("slow", "performance", "lag", "sluggish")):
            self.update_troubleshooting_state("issue_type", "Performance")
        elif any(k in text for k in ("cracked", "broken", "not turning on", "physical")):
            self.update_troubleshooting_state("issue_type", "Hardware")

        # Detect attempted solutions
        if "restart" in text or "reboot" in text:
            self.update_troubleshooting_state("attempted_solutions", "System restart")
        if "update" in text and "driver" in text:
            self.update_troubleshooting_state("attempted_solutions", "Driver update")
        if "reinstall" in text:
            self.update_troubleshooting_state("attempted_solutions", "Software reinstall")
        if "safe mode" in text or "incognito" in text:
            self.update_troubleshooting_state("attempted_solutions", "Safe/Incognito mode test")

    def chat(self, user_input):
        """Send a user message and get the support assistant's reply."""
        # Analyze input
        self.analyze_user_input(user_input)

        # Add user message to history
        self.add_to_history("user", user_input)

        # Get full conversation context
        conversation_context = self.get_conversation_context()

        # Build the prompt
        full_prompt = f"{conversation_context}\n\nUser: {user_input}\n\nSupport:"

        try:
            response = self.client.models.generate_content(
                model=self.model,
                contents=full_prompt,
            )

            text = getattr(response, "text", None)
            if text is None or not text.strip():
                return "I didn't receive a valid response. Please try again."

            text = text.strip()
            self.add_to_history("assistant", text)
            return text

        except Exception as e:
            return f"Sorry, I encountered an error: {e}"

    def reset_conversation(self):
        """Clear conversation history and reset troubleshooting state."""
        self.conversation_history = []
        self.troubleshooting_state = {
            "user_os": None,
            "user_device": None,
            "issue_type": None,
            "attempted_solutions": [],
            "user_tech_level": "unknown",
            "system_info": {},
            "current_step": None,
            "escalation_needed": False,
        }

    def get_troubleshooting_summary(self):
        """Return a short summary of what has been gathered."""
        state = self.troubleshooting_state

        has_info = any([
            state.get("issue_type"),
            state.get("user_os"),
            state.get("user_device"),
            state.get("attempted_solutions"),
        ])

        if not has_info:
            return "No troubleshooting information gathered yet."

        parts = []

        if state.get("issue_type"):
            parts.append(f"Issue: {state['issue_type']}")

        if state.get("user_os") or state.get("user_device"):
            os_str = state.get("user_os") or ""
            device_str = state.get("user_device") or ""
            system_str = f"{os_str} {device_str}".strip()
            parts.append(f"System: {system_str}")

        if state.get("attempted_solutions"):
            parts.append(f"Attempted: {', '.join(state['attempted_solutions'])}")

        if not parts:
            return "No troubleshooting information available."

        return " | ".join(parts)


def answer_support_query(query, assistant=None):
    """Answer a single support query using the chat assistant."""
    if assistant is None:
        try:
            assistant = TechSupportChat()
        except Exception as e:
            return f"Sorry, I encountered an error: {e}"

    try:
        return assistant.chat(query)
    except Exception as e:
        return f"Sorry, I encountered an error: {e}"


def interactive_mode():
    """Interactive technical support mode."""
    print("Technical Support Assistant - Interactive Mode")
    print("Type 'quit' to exit, 'reset' to start new conversation, 'summary' for troubleshooting summary")
    print("=" * 70)

    assistant = TechSupportChat()

    while True:
        user_input = input("\nYou: ").strip()

        if user_input.lower() in ["quit", "exit", "bye"]:
            print("Thank you for using technical support. Have a great day!")
            break

        if user_input.lower() == "reset":
            assistant.reset_conversation()
            print("Conversation reset. Starting fresh troubleshooting session!")
            continue

        if user_input.lower() == "summary":
            summary = assistant.get_troubleshooting_summary()
            print(f"\nTroubleshooting Summary: {summary}")
            continue

        if not user_input:
            continue

        response = assistant.chat(user_input)
        print(f"\nSupport: {response}")


def main():
    """Main function to demonstrate the technical support assistant."""
    print("Technical Support Assistant - Multi-Turn Chat")
    print("Type 'quit' to exit, 'reset' to start new conversation, 'summary' for troubleshooting summary")
    print("=" * 70)

    sample_conversations = [
        [
            "My browser keeps crashing every time I try to open it.",
            "I'm using Chrome on Windows 11.",
            "I restarted already, and it crashes right when I click the Chrome icon.",
            "Yes, it opens fine in safe mode.",
        ],
        [
            "My WiFi keeps disconnecting randomly throughout the day.",
            "It's happening on my laptop, but my phone stays connected fine.",
            "It's a Dell Inspiron from 2021, and it seems to happen mostly when I'm on video calls.",
            "I updated the driver but the issue is still happening.",
        ],
        [
            "My laptop screen is cracked and does not turn on.",
        ],
    ]

    # Initialize assistant
    try:
        assistant = TechSupportChat()
    except Exception as e:
        print(f"Failed to initialize assistant: {e}")
        return

    for i, conversation in enumerate(sample_conversations):
        print(f"\n--- Sample Troubleshooting Session {i+1} ---")
        for query in conversation:
            print(f"\nUser: {query}")
            response = answer_support_query(query, assistant)
            print(f"Support: {response}")

        summary = assistant.get_troubleshooting_summary()
        print(f"\nTroubleshooting Summary: {summary}")
        assistant.reset_conversation()


if __name__ == "__main__":
    main()