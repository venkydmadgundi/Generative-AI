import os
import json
import requests
from dotenv import load_dotenv
from typing import Optional, Dict, Any
from utils.config import SYSTEM_PROMPT
from utils.parser import WeatherParser
from google import genai

# Load environment variables
load_dotenv()


class WeatherAPIClient:
    """Client for fetching weather data from OpenWeatherMap API."""

    def __init__(self, api_key: Optional[str] = None):
        # Initialize API key from parameter or env var WEATHER_API_KEY
        self.api_key = api_key or os.getenv("WEATHER_API_KEY")

        # Raise ValueError if no key
        if not self.api_key:
            raise ValueError(
                "WEATHER_API_KEY is not set. Please provide an API key "
                "or set the WEATHER_API_KEY environment variable."
            )

        # Set base URL for weather API
        self.base_url = "https://api.openweathermap.org/data/2.5/weather"

    def get_weather(self, city: str) -> Dict[str, Any]:
        """Fetch weather data for a given city."""
        try:
            # Make an HTTP GET request with city, API key, metric units, and 10s timeout
            response = requests.get(
                self.base_url,
                params={
                    "q": city,
                    "appid": self.api_key,
                    "units": "metric",
                },
                timeout=10,
            )

            # Handle HTTP errors
            if response.status_code == 401:
                raise ValueError("Invalid API key")
            if response.status_code == 404:
                raise ValueError(f"City '{city}' not found")
            if response.status_code == 429:
                raise ValueError("API rate limit exceeded")

            # Call raise_for_status() before reading the response JSON
            response.raise_for_status()

            # Return the JSON response when the request is successful
            return response.json()

        except requests.exceptions.Timeout:
            raise ValueError("Request timeout - please try again")
        except requests.exceptions.ConnectionError:
            raise ValueError("Network error - please check your connection")
        except requests.exceptions.HTTPError as e:
            status_code = e.response.status_code if e.response is not None else "unknown"
            raise ValueError(f"API error: {status_code}")
        except ValueError:
            # Re-raise our own ValueErrors untouched
            raise
        except Exception as e:
            raise ValueError(f"Unexpected error: {e}")


class LLMClient:
    """Client for calling Gemini API to generate weather insights."""

    def __init__(self, api_key: Optional[str] = None):
        # Initialize API key from parameter or env var GEMINI_API_KEY
        self.api_key = api_key or os.getenv("GEMINI_API_KEY")

        # Raise ValueError if no key
        if not self.api_key:
            raise ValueError(
                "GEMINI_API_KEY is not set. Please provide an API key "
                "or set the GEMINI_API_KEY environment variable."
            )

        # Initialize Gemini client
        self.client = genai.Client(api_key=self.api_key)

        # Get the model name from env, default "gemini-2.5-flash"
        self.model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

    def generate_insights(self, weather_data: Dict[str, Any]) -> str:
        """Generate weather insights and recommendations using LLM."""
        try:
            # Format weather_data for LLM prompt
            formatted_weather = self._format_weather_for_llm(weather_data)

            # Insert the formatted weather data into SYSTEM_PROMPT
            full_prompt = SYSTEM_PROMPT.format(weather_data=formatted_weather)

            # Generate content using the configured model and prompt
            response = self.client.models.generate_content(
                model=self.model,
                contents=full_prompt,
            )

            # Return fallback message if the generated response is empty
            if response is None or not getattr(response, "text", None):
                return (
                    "Unable to generate weather insights at this time. "
                    "Please try again later."
                )

            # Return the generated response after removing extra whitespace
            return response.text.strip()

        except Exception as e:
            return f"An error occurred while generating insights: {e}"

    def _format_weather_for_llm(self, weather_data: Dict[str, Any]) -> str:
        """Format weather data for LLM prompt."""
        city = weather_data.get("city") or "Unknown"
        country = weather_data.get("country") or "Unknown"

        temperature = weather_data.get("temperature")
        temperature_str = f"{temperature}°C" if temperature is not None else "N/A"

        feels_like = weather_data.get("feels_like")
        feels_like_str = f"{feels_like}°C" if feels_like is not None else "N/A"

        description = weather_data.get("description") or "N/A"

        humidity = weather_data.get("humidity")
        humidity_str = f"{humidity}%" if humidity is not None else "N/A"

        wind_speed = weather_data.get("wind_speed")
        wind_speed_str = f"{wind_speed} m/s" if wind_speed is not None else "N/A"

        return (
            f"City: {city}\n"
            f"Country: {country}\n"
            f"Temperature: {temperature_str}\n"
            f"Feels Like: {feels_like_str}\n"
            f"Description: {description}\n"
            f"Humidity: {humidity_str}\n"
            f"Wind Speed: {wind_speed_str}"
        )


class WeatherAssistant:
    """Main assistant that coordinates weather data fetching and insights generation."""

    def __init__(self):
        # Initialize WeatherAPIClient Class
        self.weather_client = WeatherAPIClient()
        # Initialize LLMClient Class
        self.llm_client = LLMClient()
        # Initialize WeatherParser Class
        self.parser = WeatherParser()

    def get_weather_insights(self, city: str) -> Dict[str, Any]:
        """Get weather data and generate insights for a given city."""
        try:
            # Fetch the raw weather data for the given city
            raw_data = self.weather_client.get_weather(city)

            # Parse the raw weather data into a structured format
            parsed_data = self.parser.parse_weather_data(raw_data)

            # Validate the parsed weather data
            if not self.parser.validate_weather_data(parsed_data):
                return {
                    "city": city,
                    "error": "Invalid weather data received.",
                    "recommendation": (
                        "Unable to generate a recommendation because the "
                        "weather data was incomplete."
                    ),
                    "insights": "",
                }

            # Generate weather insights using the parsed weather data
            insights = self.llm_client.generate_insights(parsed_data)

            # Return a structured response
            return {
                "city": parsed_data.get("city"),
                "country": parsed_data.get("country"),
                "temperature": parsed_data.get("temperature"),
                "feels_like": parsed_data.get("feels_like"),
                "description": parsed_data.get("description"),
                "humidity": parsed_data.get("humidity"),
                "wind_speed": parsed_data.get("wind_speed"),
                "recommendation": insights,
                "insights": insights,
            }

        except Exception as e:
            # Return the error along with the city and an appropriate recommendation message
            return {
                "city": city,
                "error": str(e),
                "recommendation": (
                    f"Unable to generate a recommendation for {city}. "
                    f"Reason: {e}"
                ),
                "insights": "",
            }


def main():
    """Main function to demonstrate the weather assistant functionality."""
    test_cities = [
        "London",
        "New York",
        "Tokyo",
        "Paris",
        "Sydney",
    ]

    print("Weather Data Parser & API Assistant")
    print("=" * 50)

    assistant = WeatherAssistant()

    for city in test_cities:
        print(f"\nGetting weather insights for {city}...")
        try:
            result = assistant.get_weather_insights(city)
            print(f"Temperature: {result.get('temperature', 'N/A')}°C")
            print(f"Description: {result.get('description', 'N/A')}")
            print(f"Recommendation: {result.get('recommendation', 'N/A')}")
        except Exception as e:
            print(f"Error: {str(e)}")
        print("-" * 50)


if __name__ == "__main__":
    main()