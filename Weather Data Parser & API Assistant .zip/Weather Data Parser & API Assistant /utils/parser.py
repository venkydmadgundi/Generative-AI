"""
Weather data parser module.
Handles parsing and validation of weather API responses.
"""

from typing import Dict, Any


class WeatherParser:
    """Parser for weather API responses."""

    def parse_weather_data(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """Parse raw weather API response into structured format."""
        # Extract the city name from the 'name' field in raw_data
        city = raw_data.get("name")

        # Extract the country code from the 'country' field inside raw_data['sys']
        country = raw_data.get("sys", {}).get("country")

        # Extract the temperature from the 'temp' field inside raw_data['main']
        temperature = raw_data.get("main", {}).get("temp")

        # Extract the feels-like temperature from the 'feels_like' field inside raw_data['main']
        feels_like = raw_data.get("main", {}).get("feels_like")

        # Extract the humidity from the 'humidity' field inside raw_data['main']
        humidity = raw_data.get("main", {}).get("humidity")

        # Extract the weather description from the first item in raw_data['weather']
        weather_list = raw_data.get("weather", [])
        description = weather_list[0].get("description") if weather_list else None

        # Extract the wind speed from the 'speed' field inside raw_data['wind']
        wind_speed = raw_data.get("wind", {}).get("speed")

        # Return a dictionary containing all required fields
        return {
            "city": city,
            "country": country,
            "temperature": temperature,
            "feels_like": feels_like,
            "description": description,
            "humidity": humidity,
            "wind_speed": wind_speed,
        }

    def validate_weather_data(self, weather_data: Dict[str, Any]) -> bool:
        """Validate that weather data has required fields."""

        required_fields = [
            "city",
            "temperature",
            "description",
            "humidity",
            "wind_speed",
        ]
        # Check if required fields exist and are not None
        for field in required_fields:
            if field not in weather_data or weather_data[field] is None:
                return False
        return True

    def format_weather_for_llm(self, weather_data: Dict[str, Any]) -> str:
        """Format weather data for LLM prompt."""
        city = weather_data.get("city") or "Unknown"
        country = weather_data.get("country") or "Unknown"

        temperature = weather_data.get("temperature")
        temperature_str = f"{temperature}°C" if temperature is not None else "N/A"

        feels_like = weather_data.get("feels_like")
        feels_like_str = f"{feels_like}°C" if feels_like is not None else "N/A"

        description = weather_data.get("description") or "N/A"

        humidity = weather_data.get("humidity")
        humidity_str = f"{humidity}%" if humidity is not None else "N/A"

        wind_speed = weather_data.get("wind_speed")
        wind_speed_str = f"{wind_speed} m/s" if wind_speed is not None else "N/A"

        return (
            f"City: {city}\n"
            f"Country: {country}\n"
            f"Temperature: {temperature_str}\n"
            f"Feels Like: {feels_like_str}\n"
            f"Description: {description}\n"
            f"Humidity: {humidity_str}\n"
            f"Wind Speed: {wind_speed_str}"
        )