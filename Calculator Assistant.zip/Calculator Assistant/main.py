import os
from dotenv import load_dotenv
from google import genai
from utils.config import SYSTEM_PROMPT
from utils.parser import parse_function_call

# Load environment variables
load_dotenv()

class CalculatorAssistant:
    
    def __init__(self, api_key=None):
        # Initialize API key from parameter or env var GEMINI_API_KEY
        self.api_key = "AQ.Ab8RN6JGTqHfF2Hyw5kiTT_DKdidMLTCSejzrWtCYk9iVT4cvg"
        
        # Raise ValueError if no key found
        if not self.api_key:
            raise ValueError("No API key found. Please provide an API key or set GEMINI_API_KEY environment variable.")
        
        # Initialize Gemini client
        self.client = genai.Client(api_key=self.api_key)
        
        # Set model name to "gemini-2.5-flash"
        self.model_name = "gemini-3.5-flash-lite"
    
    def handle_function_call(self, function_name, parameters):
        """Handle the actual function call execution"""
        try:
            # Handle add_numbers function
            if function_name == "add_numbers":
                num1 = float(parameters.get("num1", 0))
                num2 = float(parameters.get("num2", 0))
                result = num1 + num2
                return f"The result of {num1} + {num2} is {result}"
            
            # Handle subtract_numbers function
            elif function_name == "subtract_numbers":
                num1 = float(parameters.get("num1", 0))
                num2 = float(parameters.get("num2", 0))
                result = num1 - num2
                return f"The result of {num1} - {num2} is {result}"
            
            else:
                return f"Unknown function: {function_name}"
                
        except Exception as e:
            return f"Error executing function: {str(e)}"
    
    def chat(self, user_input):
        """Main chat function that handles user input and decides whether to call functions"""
        try:
            # Prepare the conversation context with system prompt and user input
            full_prompt = f"{SYSTEM_PROMPT}\n\nUser: {user_input}"
            
            # Call Gemini API to get response
            response = self.client.models.generate_content(
                model=self.model_name,
                contents=full_prompt
            )
            
            # Handle empty response
            if not response or not response.text:
                return "I'm sorry, I couldn't generate a response. Please try again."
            
            response_text = response.text.strip()
            
            # Use parse_function_call() to check if response contains CALL_FUNCTION pattern
            function_name, parameters = parse_function_call(response_text)
            
            # If function call detected, parse and execute it using handle_function_call()
            if function_name and parameters:
                return self.handle_function_call(function_name, parameters)
            
            # If no function call, return the conversational response
            return response_text
            
        except Exception as e:
            return f"I encountered an error: {str(e)}. Please try again."

def answer_math_query(query, assistant=None):
    """Convenient wrapper function for math queries"""
    try:
        # Create CalculatorAssistant instance if not provided
        if assistant is None:
            assistant = CalculatorAssistant()
        
        # Call assistant.chat(query)
        return assistant.chat(query)
        
    except Exception as e:
        # Handle exceptions and return error message
        return f"Error: {str(e)}"

def main():
    """Main function to demonstrate the calculator assistant."""
    print("Simple Calculator Assistant")
    print("Type 'quit' to exit")
    print("=" * 40)
    
    # Sample test queries
    sample_queries = [
        "What is 5 plus 3?",
        "Calculate 10 minus 4",
        "Add 15 and 25",
        "Hello, how are you?",
        "What can you do?"
    ]
    
    # Initialize assistant
    try:
        assistant = CalculatorAssistant()
    except ValueError as e:
        print(f"Error: {e}")
        print("Please set GEMINI_API_KEY environment variable.")
        return
    
    print("\n--- Sample Queries ---")
    for query in sample_queries:
        print(f"\nUser: {query}")
        response = answer_math_query(query, assistant)
        print(f"Calculator: {response}")

if __name__ == "__main__":
    main()