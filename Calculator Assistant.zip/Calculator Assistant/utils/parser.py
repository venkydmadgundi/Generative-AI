import re

def parse_function_call(text):
    """
    Parse function call from text in format: CALL_FUNCTION:function_name:param1=value1,param2=value2
    
    Args:
        text (str): Text that may contain a function call
        
    Returns:
        tuple: (function_name, parameters) or (None, None) if no function call found
    """
    if not text:
        return None, None
    
    # Define regex pattern to match CALL_FUNCTION format
    pattern = r'CALL_FUNCTION:(\w+):(.+)'
    
    # Search for the pattern in the text
    match = re.search(pattern, text)
    
    # If no match found, return None, None
    if not match:
        return None, None
    
    # Extract function name from the match
    function_name = match.group(1)
    
    # Extract parameters string from the match
    params_str = match.group(2).strip()
    
    # Parse parameters string into a dictionary
    parameters = {}
    try:
        # Split by comma, then by equals sign for each parameter
        for pair in params_str.split(','):
            pair = pair.strip()
            if '=' in pair:
                key, value = pair.split('=', 1)
                key = key.strip()
                value = value.strip()
                # Try to convert to number
                try:
                    if '.' in value:
                        parameters[key] = float(value)
                    else:
                        parameters[key] = int(value)
                except ValueError:
                    parameters[key] = value
    except Exception:
        return None, None
    
    # Return function_name and parameters dictionary
    return function_name, parameters