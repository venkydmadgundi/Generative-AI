import os

def load_system_prompt():
    """Load the system prompt from prompt.txt file."""
    try:
        # Get the path to prompt.txt file in the scaffold directory
        current_dir = os.path.dirname(os.path.abspath(__file__))
        prompt_path = os.path.join(os.path.dirname(current_dir), "prompt.txt")
        
        # Open and read the prompt file with proper encoding
        with open(prompt_path, "r", encoding="utf-8") as f:
            content = f.read()
        
        # Return the content stripped of whitespace
        return content.strip()
    except FileNotFoundError:
        print(f"Error: prompt.txt not found.")
        return "You are a helpful Simple Calculator Assistant."
    except Exception as e:
        print(f"Error loading system prompt: {e}")
        return "You are a helpful Simple Calculator Assistant."

def get_system_prompt():
    """Get the system prompt for the calculator assistant."""
    return load_system_prompt()

# Simple math functions for demonstration
def add_numbers_mock(num1, num2):
    """Mock function to add two numbers"""
    return num1 + num2

def subtract_numbers_mock(num1, num2):
    """Mock function to subtract two numbers"""
    return num1 - num2

# Export the system prompt as SYSTEM_PROMPT
SYSTEM_PROMPT = get_system_prompt()