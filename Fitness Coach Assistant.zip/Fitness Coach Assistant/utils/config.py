import os


def load_system_prompt():
    """Load the system prompt from prompt.txt file."""
    try:
        # Get the path to prompt.txt file in the scaffold directory
        current_dir = os.path.dirname(os.path.abspath(__file__))
        prompt_path = os.path.join(current_dir, "..", "prompt.txt")

        # Open and read the prompt file with proper encoding
        with open(prompt_path, "r", encoding="utf-8") as f:
            content = f.read()

        # Return the content stripped of whitespace
        return content.strip()

    except FileNotFoundError:
        raise FileNotFoundError(
            "prompt.txt file not found. Please ensure it exists in the scaffold directory."
        )
    except Exception as e:
        raise RuntimeError(f"Error loading prompt.txt: {e}")


def get_system_prompt():
    """Get the system prompt for the fitness coach."""
    return load_system_prompt()


# Export the system prompt as SYSTEM_PROMPT
SYSTEM_PROMPT = get_system_prompt()