class CreateResumes < ActiveRecord::Migration[7.2]
  def change
    create_table :resumes do |t|
      t.text :content
      t.string :name
      t.text :skills
      t.integer :experience
      t.string :job_title
      t.text :summary

      t.timestamps
    end
  end
end
