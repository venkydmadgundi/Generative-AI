class Resume < ApplicationRecord
end
