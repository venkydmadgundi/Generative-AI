class ResumeAiAnalyzer
  MODEL = "openai/gpt-oss-120b"

  def initialize(resume_text)
    @resume_text = resume_text
  end

  def call
    response = client.chat(
      parameters: {
        model: MODEL,
        temperature: 0,
        messages: [
          {
            role: "system",
            content: system_prompt
          },
          {
            role: "user",
            content: @resume_text
          }
        ]
      }
    )

    JSON.parse(response.dig("choices", 0, "message", "content"))
  end

  private

  def client
    OpenAI::Client.new(
      access_token: ENV.fetch("GROQ_API_KEY"),
      uri_base: "https://api.groq.com/openai/v1"
    )
  end

  def system_prompt
    <<~PROMPT
      You are a resume analysis assistant.

      Extract information from the resume.

      Return ONLY valid JSON in exactly this format:

      {
        "name": "candidate name",
        "skills": ["skill1", "skill2"],
        "experience": 5,
        "job_title": "job title",
        "summary": "short professional summary"
      }

      Rules:
      - experience must be an integer
      - skills must be an array
      - do not invent information
      - if the candidate name is missing, return an empty string
      - return JSON only
    PROMPT
  end
end