class ResumesController < ApplicationController
  def new
    @resume = Resume.new
  end

  def create
    @resume = Resume.new(resume_params)

    begin
      result = ResumeAiAnalyzer.new(@resume.content).call

      validate_result!(result)

      @resume.assign_attributes(
        name: result["name"],
        skills: result["skills"].join(", "),
        experience: result["experience"],
        job_title: result["job_title"],
        summary: result["summary"]
      )

      @resume.save!

      redirect_to @resume

    rescue JSON::ParserError
      handle_ai_error("AI returned invalid JSON.")

    rescue KeyError
      handle_ai_error("AI response was missing required fields.")

    rescue StandardError => e
      Rails.logger.error(
        "AI Resume Analyzer Error: #{e.class}: #{e.message}"
      )

      handle_ai_error("Unable to analyze the resume.")
    end
  end

  def show
    @resume = Resume.find(params[:id])
  end

  private

  def resume_params
    params.require(:resume).permit(:content)
  end

  def validate_result!(result)
    required_fields = %w[
      name
      skills
      experience
      job_title
      summary
    ]

    required_fields.each do |field|
      raise KeyError, "Missing #{field}" unless result.key?(field)
    end

    raise "Name is missing" if result["name"].to_s.strip.empty?

    raise "Skills are missing" unless result["skills"].is_a?(Array) &&
                                      result["skills"].any?

    raise "Invalid experience" unless result["experience"].is_a?(Integer) &&
                                      result["experience"] > 0

    raise "Job title is missing" if result["job_title"].to_s.strip.empty?

    raise "Summary is missing" if result["summary"].to_s.strip.empty?
  end

  def handle_ai_error(message)
    flash.now[:alert] = message
    render :new, status: :unprocessable_entity
  end
end