"""
Configuration file for Restaurant Menu Assistant.
Handles loading the system prompt from prompt.txt file.
"""

import os


def load_system_prompt() -> str:
    """Load the system prompt from prompt.txt file."""
    try:
        # Get the path to prompt.txt file
        # The prompt.txt file is in the parent directory of the parent directory
        current_dir = os.path.dirname(os.path.abspath(__file__))
        prompt_path = os.path.join(current_dir, "..", "..", "prompt.txt")

        # Open and read the prompt file
        with open(prompt_path, "r", encoding="utf-8") as f:
            content = f.read()

        # Return the content stripped of whitespace
        return content.strip()

    except FileNotFoundError:
        raise FileNotFoundError(
            "prompt.txt not found. Please ensure it exists in the project root."
        )
    except Exception as e:
        raise RuntimeError(f"Error loading system prompt: {e}")


def get_system_prompt() -> str:
    """Get the system prompt with placeholders for restaurant data and user query."""
    return load_system_prompt()


# Export the system prompt as SYSTEM_PROMPT
SYSTEM_PROMPT = get_system_prompt()