import os
from typing import Optional
from dotenv import load_dotenv
from utils.config import SYSTEM_PROMPT
from google import genai


# Load environment variables
load_dotenv()


class LLMClient:
    """Client for calling the Gemini API."""

    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize the Gemini client.

        Args:
            api_key: Optional Gemini API key.
                     If not provided, use GEMINI_API_KEY
                     from the environment.
        """

        # Load environment variables from .env
        load_dotenv()

        # Get the API key.
        # Use the provided api_key first.
        # If it is not provided, use GEMINI_API_KEY from the environment.
        self.api_key = api_key or os.getenv("GEMINI_API_KEY")

        # Raise ValueError if no API key is available.
        if not self.api_key:
            raise ValueError(
                "GEMINI_API_KEY is not set. Please provide an API key "
                "or set the GEMINI_API_KEY environment variable."
            )

        # Initialize the Gemini client.
        self.client = genai.Client(api_key=self.api_key)

        # Store the model name.
        self.model_name = "gemini-2.5-flash"

    def call(self, user_query: str) -> str:
        """Call the LLM with the system prompt and user query."""

        # Create a prompt that combines:
        # 1. SYSTEM_PROMPT
        # 2. user_query
        # Keep the system instructions and user query clearly separated.
        full_prompt = SYSTEM_PROMPT.replace("{user_query}", user_query)

        try:
            # Call the Gemini model using client.models.generate_content()
            response = self.client.models.generate_content(
                model=self.model_name,
                contents=full_prompt,
            )

            # Check whether the response contains text.
            if response is None or not getattr(response, "text", None):
                return (
                    "I'm sorry, I couldn't generate a response at this time. "
                    "Please try again."
                )

            # Return the response text.
            return response.text.strip()

        except Exception as e:
            # Handle API errors appropriately.
            return f"An error occurred while contacting the assistant: {e}"


class MenuAssistant:
    """Assistant that answers restaurant-related queries using an LLM."""

    def __init__(self):
        """Initialize the menu assistant."""

        # Load environment variables.
        load_dotenv()

        # Initialize an LLMClient.
        self.llm_client = LLMClient()

    def answer(self, query: str) -> str:
        """Answer a user's restaurant-related question."""

        # Validate that the query is not empty.
        if query is None or not query.strip():
            return "Please provide a valid question about restaurants."

        try:
            # Call LLMClient.call() with the user's query.
            return self.llm_client.call(query.strip())
        except Exception as e:
            # Handle exceptions appropriately.
            return f"An error occurred while processing your query: {e}"


def main():
    test_queries = [
        "What should I order at Sakura Sushi?",
        "What's the best dish at Bella Pasta?",
        "Tell me a joke",
    ]

    print("Restaurant Menu Assistant")
    print("=" * 40)

    assistant = MenuAssistant()

    for query in test_queries:
        print(f"\nQuery: {query}")
        result = assistant.answer(query)
        print(f"Response: {result}")
        print("-" * 40)


if __name__ == "__main__":
    main()